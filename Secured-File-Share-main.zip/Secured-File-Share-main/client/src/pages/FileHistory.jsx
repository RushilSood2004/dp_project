import React from 'react'
import { PageHeader } from '../components'

const FileHistory = () => {
  return (
    <div>
      <PageHeader title="File History Page" path="Home > File History Page" />
    </div>
  )
}

export default FileHistory